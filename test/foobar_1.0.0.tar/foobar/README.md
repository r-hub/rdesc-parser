
# foobar

> Foobar Package

[![Linux Build Status](https://travis-ci.org/gaborcsardi/foobar.svg?branch=master)](https://travis-ci.org/gaborcsardi/foobar)

[![Windows Build status](https://ci.appveyor.com/api/projects/status/github/gaborcsardi/foobar?svg=true)](https://ci.appveyor.com/project/gaborcsardi/foobar)
[![](http://www.r-pkg.org/badges/version/foobar)](http://www.r-pkg.org/pkg/foobar)
[![CRAN RStudio mirror downloads](http://cranlogs.r-pkg.org/badges/foobar)](http://www.r-pkg.org/pkg/foobar)


Just a package to use in test cases.

## Installation

```r
devtools::install_github("gaborcsardi/foobar")
```

## Usage

```r
library(foobar)
```

## License

MIT + file LICENSE © 
