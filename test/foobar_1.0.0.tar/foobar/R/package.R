
#' Foobar Package
#'
#' Just a package to use in test cases.
#'
#' @docType package
#' @name foobar
NULL
